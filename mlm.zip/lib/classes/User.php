<?php 
class User extends DB
{
	var $commonObjContent;
	var $encryObj;
	private static $RPVal=0;
	function __construct(){
		$this->commonObjContent=new Common();
		$this->encryObj = new Encryption();
		parent:: __construct(DB_NAME,DB_HOST,DB_USERNAME,DB_PASSWORD);		
	}	
	
	function CheckUserPosition($uid){
		$uid = 'SM100'.$uid;
		$query = "SELECT * FROM ".TBL_PREFIX."_users where status = 1 AND parent_id='".$uid."'";
		$result = $this->query($query);
		return $this->numRows($result);
	
	}
	function getTotalLeg($memid,$leg){ 
  			$sql = "select * from ".TBL_PREFIX."_users where parent_id='".$memid."' and position='".$leg."'";    
  			$res = $this->query($sql);  
  			global $total;
    
  			$total = $total + $this->numRows($res);
  			$row = $this->fetchNextObject($res);
 
			 if(!empty($row->uid)){ 
			 	$uid = 'SM100'.$row->uid;
			   $this->getTotalLeg ($uid,'1');
			   $this->getTotalLeg ($uid,'2');
			  }

    		return $total;
    }
	
	function FindTotalUserId($memid,$leg){
  		 $sql="select * from ".TBL_PREFIX."_users where parent_id='".$memid."' and position='".$leg."'";    
  			$res=$this->query($sql);  
  			global $returnArr;
  			$row=$this->fetchNextObject($res);
			if(!empty($row->uid)){
 			$returnArr  .= $row->uid.","; 
			 if($row->uid !=''){
			 	$uid = 'SM100'.$row->uid;
			   $this->FindTotalUserId ($uid,'1');
			   $this->FindTotalUserId ($uid,'2');
			  }
			}
    		return $returnArr;
    }
	function UserPositionId($uid){
		$Arr = array();
		$query = "SELECT * FROM ".TBL_PREFIX."_users where parent_id = '".$uid."'";
		$result = $this->query($query);
		while($line = $this->fetchNextObject($result)){
			if($line->position == 1){
				$Arr['right'] = $line->uid;
			}else{
				$Arr['left'] = $line->uid;
			}
		}
		
		return $Arr;
	}
	function GenerateCommissionVal(){
		$query = "SELECT * FROM ".TBL_PREFIX."_users where 1=1 AND DATE(created) = CURDATE() AND status = 1";
		$result = $this->query($query);
		$commissionConfig = $this->getCommissionConfig();
		
		
		while($line = $this->fetchNextObject($result)){			
			 $position = $this->CheckUserPosition($line->uid);
				if($position == 2){ 
					$uid = 'SM100'.$line->uid;
					$LegPosition = $this->UserPositionId($uid);
					$perviousVal = $this->FetchPreviousUserCommission($line->uid);
					
					if(!empty($perviousVal->inactive_user_id)){
						$InactiveUserId = $perviousVal->inactive_user_id;
					}else{
						$this->FindTotalUserId('SM100'.$LegPosition['right'],1);
						$value = $this->FindTotalUserId('SM100'.$LegPosition['left'],2);
						$value = trim($value, ",");
						$InactiveUserId = $this->FindInactiveUserId($value);
					}
					//echo 'Inactive user='.$InactiveUserId.'<br>';					
					$rightLeg = $this->getTotalLeg($uid,1); // right leg total user					
					$leftLeg = $this->getTotalLeg($uid,2); 
					$leftLeg = ($leftLeg - $rightLeg); //  left leg total user
					
					$minVal = 0;
					$rasio = 0;
					$RightfinalArr = explode(',',trim($this->getTotalLegRightUserId($uid,1), ","));					
					$LeftfinalArr = explode(',',trim($this->getTotalLegLeftUserId($uid,2), ","));
					
					if(!empty($perviousVal->right_remaining_users)){
						$RightRemainuserId = explode(',',$perviousVal->right_remaining_users);
						$rightLeg = $rightLeg + count($RightRemainuserId);						
						$RightfinalArr = array_merge($LeftRemainuserId,$RightfinalArr);
					}
					if(!empty($perviousVal->left_remaining_users)){
						$LeftRemainuserId = explode(',',$perviousVal->left_remaining_users);
						$leftLeg = $leftLeg + count($LeftRemainuserId);						
						$LeftfinalArr = array_merge($LeftRemainuserId,$LeftfinalArr); 
					}
					
						$minVal = $rightLeg; // minimum user count accroding position
						$rasio = "$rightLeg : $leftLeg"; // for rasio						
						$commissionVal = 0; // store main commission
						$dirIncome = 0; // store direct income
						$inDirIncome = 0; // store indirect income
						
					if($rightLeg <= $leftLeg){	
																
						$temp = $LeftfinalArr; 						
						$Rcommission = 0;
						$Lcommission = 0;
						
						for($i=0;$i<$rightLeg;$i++){  //for right leg commission count							 
							$RightId = $RightfinalArr[$i];
							$UserDetail = $this->GetUserPackageDetail($RightId);
							
							if($UserDetail->uid != $InactiveUserId){
								$packagePoint = $UserDetail->package_point;
								 $Rcommission = $Rcommission +($packagePoint * $commissionConfig->point_value);
							}
							for($j=$i;$j<=$i;$j++){  // for left leg commission count							
							$LeftId = $LeftfinalArr[$j];
								$UserDetail = $this->GetUserPackageDetail($LeftId);
								
								if($UserDetail->uid != $InactiveUserId){
									$packagePoint = $UserDetail->package_point;
									 $Lcommission = $Lcommission +($packagePoint * $commissionConfig->point_value);
								}
								unset($temp[$j]);							
							}
						}
						$commissionVal = ($Rcommission + $Lcommission);
						// for direct income
						$sponsorId = $line->sponsor_id;
						$DirectIncomeUserId = $this->GenerateActualUserId($sponsorId);
						$sponsorComm = $this->FetchPreviousUserCommission($DirectIncomeUserId);
						if(!empty($sponsorComm->uid)){
                                                    $ScommGeneDate = $sponsorComm->commissin_generate_date;
                                                    $dirIncome = (($commissionVal * $commissionConfig->direct_income)/100);
                                                    $query = "UPDATE ".TBL_PREFIX."_user_commission SET direct_income='".$dirIncome."' WHERE uid = '".$DirectIncomeUserId."' AND commissin_generate_date = $ScommGeneDate";
                                                    $this->query($query);
                                                }
						// for indirect income
						$UserParentId = $line->parent_id;
						$InDirectIncomeUserId = $this->GenerateActualUserId($UserParentId);
						$ParentComm = $this->FetchPreviousUserCommission($InDirectIncomeUserId);
						if(!empty($ParentComm->uid)){
                                                    $PcommGeneDate = $ParentComm->commissin_generate_date;
                                                    $inDirIncome = (($commissionVal * $commissionConfig->indirect_income)/100);
                                                    $query = "UPDATE ".TBL_PREFIX."_user_commission SET indirect_income='".$inDirIncome."' WHERE uid = '".$InDirectIncomeUserId."' AND commissin_generate_date = $PcommGeneDate";
                                                }
						$LeftRemainingUserId = implode(',',$temp);						
						$commissionVal = $commissionVal - ($dirIncome + $inDirIncome);
						
						$query = "INSERT INTO ".TBL_PREFIX."_user_commission SET uid='".$line->uid."',commission_value=".$commissionVal.",direct_income=0,indirect_income=0,right_remaining_users='".$LeftRemainingUserId."' ,inactive_user_id='".$InactiveUserId."',commissin_generate_date=CURDATE()";
						$lastId = $this->lastInsertedId($this->query($query));
						if($lastId)
						return true;
						else
						return false;
					}else{					
						$temp = $RightfinalArr; 						
						$Rcommission = 0;
						$Lcommission = 0;
						
						for($i=0;$i<$leftLeg;$i++){  //for left leg commission count							 
							
							$LeftId = $LeftfinalArr[$i];
								$UserDetail = $this->GetUserPackageDetail($LeftId);
								
								if($UserDetail->uid != $InactiveUserId){
									$packagePoint = $UserDetail->package_point;
									 $Lcommission = $Lcommission +($packagePoint * $commissionConfig->point_value);
								}						
							
							for($j=$i;$j<=$i;$j++){  // for right leg commission count							
								$RightId = $RightfinalArr[$j];
								$UserDetail = $this->GetUserPackageDetail($RightId);
								
								if($UserDetail->uid != $InactiveUserId){
									$packagePoint = $UserDetail->package_point;
								 	$Rcommission = $Rcommission +($packagePoint * $commissionConfig->point_value);
								}
								unset($temp[$j]);							
							}
						}
						$commissionVal = ($Rcommission + $Lcommission);
						// for direct income
						$sponsorId = $line->sponsor_id;
						$DirectIncomeUserId = $this->GenerateActualUserId($sponsorId);
						$sponsorComm = $this->FetchPreviousUserCommission($DirectIncomeUserId);
						if(!empty($sponsorComm->uid)){
                                                    $ScommGeneDate = $sponsorComm->commissin_generate_date;
                                                    $dirIncome = (($commissionVal * $commissionConfig->direct_income)/100);
                                                    $query = "UPDATE ".TBL_PREFIX."_user_commission SET direct_income='".$dirIncome."' WHERE uid = '".$DirectIncomeUserId."' AND commissin_generate_date = $ScommGeneDate";
                                                    $this->query($query);
                                                }    
						// for indirect income
						$UserParentId = $line->parent_id;
						$InDirectIncomeUserId = $this->GenerateActualUserId($UserParentId);
						$ParentComm = $this->FetchPreviousUserCommission($InDirectIncomeUserId);
						if(!empty($ParentComm->uid)){
                                                    $PcommGeneDate = $ParentComm->commissin_generate_date;
                                                    $inDirIncome = (($commissionVal * $commissionConfig->indirect_income)/100);						
                                                    $query = "UPDATE ".TBL_PREFIX."_user_commission SET indirect_income='".$inDirIncome."' WHERE uid = '".$InDirectIncomeUserId."' AND commissin_generate_date = $PcommGeneDate";
                                                    $this->query($query);
                                                }
						
						$RightRemainingUserId = implode(',',$temp);
						$commissionVal = $commissionVal - ($dirIncome + $inDirIncome);
						
						$query = "INSERT INTO ".TBL_PREFIX."_user_commission SET uid='".$line->uid."',commission_value=".$commissionVal.",direct_income=0,indirect_income=0,right_remaining_users='".$RightRemainingUserId."' ,inactive_user_id='".$InactiveUserId."',commissin_generate_date=CURDATE()";
						$lastId = $this->lastInsertedId($this->query($query));
						if($lastId)
						return true;
						else
						return false;
					}
					
						
						
						
				}
		}
	}
	function GenerateActualUserId($userId){
		$del="SM100";
		$pos=strpos($userId, $del);
		$id=substr($userId, $pos+strlen($del)-0, strlen($userId)-0);
		return $id;
	}
	function FetchPreviousUserCommission($id){ 
		$query = "SELECT * FROM ".TBL_PREFIX."_user_commission where uid = '".$id."' ORDER BY cid DESC LIMIT 1";
		$result = $this->query($query);
		$line = $this->fetchNextObject($result);
		return $line;
	}
	function getCommissionConfig(){
		$adminArr = $this->query("select * from ".TBL_PREFIX."_commission_setting where id=1");
		$rows = $this->numRows($adminArr);
		if($rows>0){
			$qr=$this->fetchNextObject($adminArr);
			return $qr;
		} 
	}
	function getTotalLegRightUserId($memid,$leg){
  		 $sql="select * from ".TBL_PREFIX."_users where parent_id='".$memid."' and position='".$leg."'";    
  			$res=$this->query($sql);  
  			global $rightArr;
  			$row=$this->fetchNextObject($res);
			if(!empty($row->uid)){
 			$rightArr  .= $row->uid.","; 
			 if($row->uid !=''){
			 	$uid = 'SM100'.$row->uid;
			   $this->getTotalLegRightUserId($uid,'1');
			   $this->getTotalLegRightUserId($uid,'2');
			  }
			}
    		return $rightArr;
    }
	function getTotalLegLeftUserId($memid,$leg){
  		 $sql="select * from ".TBL_PREFIX."_users where parent_id='".$memid."' and position='".$leg."'";    
  			$res=$this->query($sql);  
  			global $leftArr;
  			$row=$this->fetchNextObject($res);
			if(!empty($row->uid)){
 			$leftArr  .= $row->uid.","; 
			 if($row->uid !=''){
			 	$uid = 'SM100'.$row->uid;
			   $this->getTotalLegLeftUserId ($uid,'1');
			   $this->getTotalLegLeftUserId ($uid,'2');
			  }
			}
    		return $leftArr;
    }
	function FindInactiveUserId($str){
	 $qry = "SELECT uid FROM ".TBL_PREFIX."_users WHERE uid IN ($str) ORDER BY DATE(created) ASC , TIME(created) ASC limit 1";
	$result = $this->query($qry);
	$line = $this->fetchNextObject($result);
	return $line->uid;
	}
	function UpdateUserRPWallet($value){
		$id = $_SESSION['UID'];		
  		$query = "SELECT * FROM ".TBL_PREFIX."_wallet where uid='".$id."'";
    	$result = $this->query($query);
		
		if($this->numRows($result) > 0){
			$query = "UPDATE ".TBL_PREFIX."_wallet SET right_rp_value=".$value['rightRPVal'].",left_rp_value=".$value['leftRPVal'].",updated=NOW() WHERE uid='".$id."'";
		}else{
				$query = "INSERT INTO ".TBL_PREFIX."_wallet SET uid=$id,right_rp_value=".$value['rightRPVal'].",left_rp_value=".$value['leftRPVal']." ,status=1,created=NOW()";
			}		
		$this->query($query);
	}
	function getUserRPValue($UserChild){
	$Arr = array();
	$rightUser = 0;
	$rightRPVal = 0;
	$leftUser = 0;
	$leftRPVal = 0;
	if(!empty($UserChild)){
	
		if(!empty($UserChild['RightUser'])){
		$RightVal = $this->CalculateRPValue(0,$UserChild['RightUser']);
		
			if(!empty($RightVal)){
				$rightUser = $RightVal['users'];
				$rightRPVal = $RightVal['rpvalu'];
			}else{
				$rightUser = 0;
				$rightRPVal = 0;
			}
		}else{
			$rightUser = 0;
			$rightRPVal = 0;
		}	
		if(!empty($UserChild['LeftUser'])){
			$LeftUser = $this->CalculateRPValue(0,$UserChild['LeftUser']);
			
				if(!empty($LeftUser)){
					$leftUser = ($LeftUser['users'] - $rightUser);
					$leftRPVal = ($LeftUser['rpvalu'] - $rightRPVal);
				}else{
					
				}
		}else{
			$leftUser = 0;
			$leftRPVal = 0;
		}	
	  }
	  $Arr = array(
	  	'rightUser'  =>$rightUser,
	  	'rightRPVal' =>number_format($rightRPVal,2),
	  	'leftUser'   =>$leftUser,
	  	'leftRPVal'  =>number_format($leftRPVal,2)
 	  );
	  return $Arr;
	}
	
	function CalculateRPValue($val, $parentID=null)
	{ 		
		static $val;
		static $users;
		// Create the query
		$sql = "SELECT * FROM ".TBL_PREFIX."_users WHERE ";
		if($parentID == null) {
			$sql .= "parent_id IS NULL";
		}
		else {
			$sql .= "parent_id = '$parentID'";
		}
			
		$del="SM100";
		$pos=strpos($parentID, $del);
		$id=substr($parentID, $pos+strlen($del)-0, strlen($parentID)-0);
		
		$packages = $this->GetUserPackageDetail($id);
		if(!empty($packages->package_rp)){
			$val = $val + $packages->package_rp;
			++self::$RPVal;
		}
		// Execute the query and go through the results.
		$result = $this->query($sql);
		if($result)
		{
			while($line = $this->fetchNextObject($result))
			{
				
				// Print the current ID;
				$currentID = 'SM100'.$line->uid;
				
				$this->CalculateRPValue($val, $currentID);
			}			
		}
		else
		{
			die("Failed to execute query! ( $parentID)");
		}
		return array(
		'rpvalu'=>$val,
		'users'=>self::$RPVal
		);
	}
	
	function GetUserPackageDetail($id){
		$sql = "SELECT * FROM ".TBL_PREFIX."_users WHERE ";
		if($id == null) {
			$sql .= "uid IS NULL";
		}
		else {
			$sql .= "uid='$id'";
		}	
		//Execute the query and go through the results.
		$result = $this->query($sql);
		if($result)
		{
			$line = $this->fetchNextObject($result);	
			if($line->user_pin){
				$sql = "SELECT * FROM ".TBL_PREFIX."_tokens as t LEFT JOIN tbl_packages AS p ON t.pid = p.pid LEFT JOIN tbl_users AS u ON u.user_pin = t.token WHERE token = '".$line->user_pin."' ";
				$line = $this->fetchNextObject($this->query($sql));
				return $line;				
			}
		}
	}
	function ChildNode($id)
	{
		$query = "SELECT * FROM ".TBL_PREFIX."_users where parent_id='".$id."' LIMIT 2";
    	$check_parent_node = $this->query($query);
		
    	if($this->numRows($check_parent_node) > 0)
    		{				
				 while($line = $this->fetchNextObject($check_parent_node))
				{	if($line->position == '2')
					{
						$posts['children']= array('name'=>$line->username);
						
					}
					else
					{
					$posts['children']= array('name'=>$line->username);
						
					}
					$this->ChildNode('SM100'.$line->uid);
					
				}
        		

    		}
	}
	
	function CreateBTreePosition($id){
	$userData = $this->getUser($_SESSION['UID']);
		$response = array();
		
		$posts['name']= $userData->username; 
  		$query = "SELECT * FROM ".TBL_PREFIX."_users where parent_id='".$id."' LIMIT 2";
    	$check_parent_node = $this->query($query);
		
    	if($this->numRows($check_parent_node) > 0)
    		{				
				 while($line = $this->fetchNextObject($check_parent_node))
				{	
				
				if($line->position == '2')
					{
						$posts['children'][] = array('name'=>$line->username);
						
					}
					else
					{
					$posts['children'][] = array('name'=>$line->username);
						
					}
					//$this->ChildNode('SM100'.$line->uid);
				}
    		}else{
				$posts['children'][] = array();
			}
			
					
					$json = json_encode($posts);
					$userId = $_SESSION['UID'];
					$path = "script/".$userId."/";					
					$file = $path.'file.json';
					file_put_contents($file, $json);
	}
	
	function validateUserLogin(){
   
		if(($_SESSION['UID'] == null )&&($_SESSION['UNAME'] == null )) {
		
			$this->commonObjContent->wtRedirect("index.php"); 
		} 
	}
	
	function UpdateUserProfile($params,$img=null){
		$this->query("UPDATE ".TBL_PREFIX."_users SET username='".$this->commonObjContent->praseData($params['username'])."',address='".$this->commonObjContent->praseData($params['address'])."',mobile='".$this->commonObjContent->praseData($params['mobile'])."',profile_image='".$this->commonObjContent->praseData($img)."',acct_holder_name='".$this->commonObjContent->praseData($params['acct_holder_name'])."',pancard='".$this->commonObjContent->praseData($params['pancard'])."',city='".$this->commonObjContent->praseData($params['city'])."',state='".$this->commonObjContent->praseData($params['state'])."',country='".$this->commonObjContent->praseData($params['country'])."',bank_name='".$this->commonObjContent->praseData($params['bank_name'])."',acct_number='".$this->commonObjContent->praseData($params['acct_number'])."',branch_code='".$this->commonObjContent->praseData($params['branch_code'])."',updated=NOW() WHERE uid = '".intval($_SESSION['UID'])."'");
		$this->commonObjContent->pushMessage("Profile has been changed successfully.");
		//$this->commonObjContent->wtRedirect("package.php");
	}
	function ChangeUserPin($params){
	 	
		$qr = "SELECT * FROM ".TBL_PREFIX."_tokens where token='".$this->commonObjContent->praseData($params['user_pin'])."'";
		$QryRs =$this->query($qr);
		if($this->numRows($QryRs)==0) {
			$this->commonObjContent->pushError("Invalid pin enter by user.");
		}else{		
		$query = "SELECT * FROM ".TBL_PREFIX."_users where user_pin='".$this->commonObjContent->praseData($params['user_pin'])."'";
		$QryRs =$this->query($query);
		if($this->numRows($QryRs)==0) {
			$this->query("UPDATE ".TBL_PREFIX."_users SET user_pin='".$this->commonObjContent->praseData($params['user_pin'])."',updated=NOW()  where uid = '".intval($_SESSION['UID'])."'");
		$token = $this->commonObjContent->praseData($params['user_pin']);
		$this->query("update ".TBL_PREFIX."_tokens set status=0 where token='".$token."'");					
		$this->commonObjContent->pushMessage("Package has been changed successfully.");
		$this->commonObjContent->wtRedirect("package.php");
		}else{
			$this->commonObjContent->pushMessage("Pin already assign to another.");						
			$this->commonObjContent->wtRedirect("update_package.php?pid=".$params['pid']);
		  }			
		}
	}
	
	function updateUser($params,$PASS)
	{	
		if(empty($params['user_pin'])){
			$this->query("update ".TBL_PREFIX."_users set username='".$this->commonObjContent->praseData($params['username'])."',parent_id='".$this->commonObjContent->praseData($params['parent_id'])."',email='".$this->commonObjContent->praseData($params['email'])."',password='".$PASS."',position='".$this->commonObjContent->praseData($params['position'])."',sponsor_id='".$this->commonObjContent->praseData($params['sponsor_id'])."',address='".$this->commonObjContent->praseData($params['address'])."',mobile='".$this->commonObjContent->praseData($params['mobile'])."',user_pin = '".$this->commonObjContent->praseData($params['user_pin'])."',status = 0,date_of_birth='".$this->commonObjContent->praseData($params['date_of_birth'])."',updated=NOW()  where uid = '".intval($params['uid'])."'");
		}else{
			$this->query("update ".TBL_PREFIX."_users set username='".$this->commonObjContent->praseData($params['username'])."',parent_id='".$this->commonObjContent->praseData($params['parent_id'])."',email='".$this->commonObjContent->praseData($params['email'])."',password='".$PASS."',position='".$this->commonObjContent->praseData($params['position'])."',sponsor_id='".$this->commonObjContent->praseData($params['sponsor_id'])."',address='".$this->commonObjContent->praseData($params['address'])."',mobile='".$this->commonObjContent->praseData($params['mobile'])."',user_pin = '".$this->commonObjContent->praseData($params['user_pin'])."',status = 1 ,date_of_birth='".$this->commonObjContent->praseData($params['date_of_birth'])."',updated=NOW()  where uid = '".intval($params['uid'])."'");	
		$token = $this->commonObjContent->praseData($params['user_pin']);
		$this->query("update ".TBL_PREFIX."_tokens set status=0 where token='".$token."'");					
	}
	$this->commonObjContent->pushMessage("User updated successfully.");
	$this->commonObjContent->wtRedirect("user.php");
	
	}
	function forgetPassword($uid){		
			if (strpos($uid,'SM100') !== false) {
				$del="SM100";
				$pos=strpos($uid, $del);
				$id=substr($uid, $pos+strlen($del)-0, strlen($uid)-0);
				$qry = "SELECT * FROM ".TBL_PREFIX."_users where uid = '".$id."' ";
				$row = $this->query($qry);
				if($this->NumRows($row) > 0){
					$line = $this->fetchNextObject($row);
					$smsMsg = "Your password : ".$this->encryObj->decode($line->password);	
                	// send msg api intregration   
                	$this->SendMsgToUser($line->mobile,$smsMsg);
					$this->commonObjContent->pushMessage("Your passwrod sent to your mobile device.");

				}
    			}else{
					$this->commonObjContent->pushError("Invalid user Id.");	
				}
		
		
	}
	function getUserPackage($UserPin){	
	$record = '';
	$qry = "SELECT * FROM `tbl_tokens` AS token LEFT JOIN tbl_packages AS package ON token.pid = package.pid WHERE token.token = '".$UserPin."'";
		$row = $this->query($qry);
		if($this->NumRows($row) > 0){
			$record = $this->fetchNextObject($row);
		}
		
		return $record;
	}
	
	function getTreePosition($sponsorId){
	$Right = 0;
	$Left  = 0;
	$result = array();
	$qry = "SELECT * FROM ".TBL_PREFIX."_users where parent_id = '".$sponsorId."' ";
		$row = $this->query($qry);
		if($this->NumRows($row) > 0){
			while($record = $this->fetchNextObject($row)){
				if($record->position == 1){
				$Right++;	
				}
				if($record->position == 2){
					$Left++;
				}
			}
		}
		$result = array(
			'Right' => $Right,
			'Left'  => $Left,
			'String' => 'Right Position = '.$Right.' Left Position = '.$Left
		);
		return $result;
	}
	function AddUser($params,$PASS,$from=null){	
	
	if(!empty($params['user_pin'])){
	$query = "SELECT * FROM ".TBL_PREFIX."_tokens where token = '".$this->commonObjContent->praseData($params['user_pin'])."' AND (status = 1 OR status = 2)";
		$QryRs =$this->query($query);
		if($this->numRows($QryRs) > 0) {
		$Str = $this->commonObjContent->praseData($params['parent_id']);			
			if (strpos($Str,'SM100') !== false) {
    			$UserPos = $this->getUserPosition($this->commonObjContent->praseData($params['parent_id']),$this->commonObjContent->praseData($params['position']));
				if($UserPos){
					$this->query("INSERT INTO ".TBL_PREFIX."_users set user_pin='".$this->commonObjContent->praseData($params['user_pin'])."',parent_id='".$this->commonObjContent->praseData($params['parent_id'])."',username='".$this->commonObjContent->praseData($params['username'])."',email='".$this->commonObjContent->praseData($params['email'])."',password='".$PASS."',position='".$this->commonObjContent->praseData($params['position'])."',sponsor_id='".$this->commonObjContent->praseData($params['sponsor_id'])."',address='".$this->commonObjContent->praseData($params['address'])."',mobile='".$this->commonObjContent->praseData($params['mobile'])."',date_of_birth='".$this->commonObjContent->praseData($params['date_of_birth'])."',created=CURDATE(),status=1");
		$token = $this->commonObjContent->praseData($params['user_pin']);
		$userId = mysql_insert_id();
		$this->query("update ".TBL_PREFIX."_tokens set status=0 where token='".$token."'");	
		$smsMsg = "Your User Pin : SM100".$userId." and Password : ".$params['password'];	
                // send msg api intregration   
                $this->SendMsgToUser($params['mobile'],$smsMsg);
            $msg = "Congratulation ".$this->commonObjContent->praseData($params['username']).",<br> Registration has been successfully. Your User pin is : SM100".$userId.". Remember it for further.";
                
			$this->commonObjContent->pushMessage($msg);						
	
				}else{
						$UserMsg = '';
						if($params['position'] == 1){
							$UserMsg = "Parent's right position already filled out.";
						}else{
							$UserMsg = "Parent's left position already filled out.";
						}
						$this->commonObjContent->pushError($UserMsg);
					if($from == 'front'){		
						$this->commonObjContent->wtRedirect("register.php");
					}else{			
						$this->commonObjContent->wtRedirect("add_user.php");
					}
				}	
			}else{
				$this->commonObjContent->pushError("Invalid Parent Id.");
				if($from == 'front'){		
					$this->commonObjContent->wtRedirect("register.php");
				}else{			
					$this->commonObjContent->wtRedirect("add_user.php");
				}
			}
		}else{
			$this->commonObjContent->pushError("Invalid Pin");						
			if($from == 'front'){		
				$this->commonObjContent->wtRedirect("register.php");
			}else{			
				$this->commonObjContent->wtRedirect("add_user.php");
			}
		  }	
		}else{
		
			$Str = $this->commonObjContent->praseData($params['parent_id']);			
			if (strpos($Str,'SM100') !== false) {
    			$UserPos = $this->getUserPosition($this->commonObjContent->praseData($params['parent_id']),$this->commonObjContent->praseData($params['position']));
				if($UserPos){
			
			$this->query("INSERT INTO ".TBL_PREFIX."_users set parent_id='".$this->commonObjContent->praseData($params['parent_id'])."',username='".$this->commonObjContent->praseData($params['username'])."',email='".$this->commonObjContent->praseData($params['email'])."',password='".$PASS."',position='".$this->commonObjContent->praseData($params['position'])."',sponsor_id='".$this->commonObjContent->praseData($params['sponsor_id'])."',address='".$this->commonObjContent->praseData($params['address'])."',mobile='".$this->commonObjContent->praseData($params['mobile'])."',date_of_birth='".$this->commonObjContent->praseData($params['date_of_birth'])."',created=CURDATE()");
		$userId = mysql_insert_id();
		//$this->commonObjContent->pushMessage("User added successfully.");			
			}else{
						$UserMsg = '';
						if($params['position'] == 1){
							$UserMsg = "Parent's right position already filled out.";
						}else{
							$UserMsg = "Parent's left position already filled out.";
						}
						$this->commonObjContent->pushError($UserMsg);
					if($from == 'front'){		
						$this->commonObjContent->wtRedirect("register.php");
					}else{			
						$this->commonObjContent->wtRedirect("add_user.php");
					}
				}
		}else{
				$this->commonObjContent->pushError("Invalid Parent Id.");
				if($from == 'front'){		
					$this->commonObjContent->wtRedirect("register.php");
				}else{			
					$this->commonObjContent->wtRedirect("add_user.php");
				}
			}
		
			if($from == 'front'){		
			$msg = "Congratulation ".$this->commonObjContent->praseData($params['username']).",<br> Registration has been successfully. Your User pin is : SM100".$userId.". Remember it for further.";
			// send msg api intregration 
				$smsMsg = "Your User Pin : SM100".$userId." and Password : ".$params['password'];	
                // send msg api intregration   
                $this->SendMsgToUser($params['mobile'],$smsMsg);
				$this->commonObjContent->pushMessage($msg);
				$this->commonObjContent->wtRedirect("register.php");
			}else{			
				$this->commonObjContent->wtRedirect("user.php");
			}
		}	
	}
        
function SendMsgToUser($mob,$smsMsg){
            $url = "http://sms.sasquare.in/api/sendmsg.php";
   
            $data = array (
              'user' => '8923604624',
              'pass' => '8923604624',
              'sender' => 'SMMPVL',
              'phone' => "$mob",
              'text' => "$smsMsg",
              'priority' => 'sdnd',
              'stype' => 'normal'
             );
       
              $params = '';
              foreach($data as $key=>$value)
               $params .= $key.'='.$value.'&';
               $params = rtrim($params, '&');
               $ch = curl_init();
       		curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_URL, $url); //Remote Location URL
    
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); //Return data instead printing directly in Browser
            curl_setopt($ch, CURLOPT_HEADER, 0);
            //We add these 2 lines to create POST request
            curl_setopt($ch, CURLOPT_POST, count($data)); //number of parameters sent
            curl_setopt($ch, CURLOPT_POSTFIELDS, $params); //parameters data
            $result = curl_exec($ch);
       		//curl_errno($ch)
            curl_close($ch);
        }

	function getUserPosition($parentId,$position){
		$result = '';
		$q = $this->query("select * from ".TBL_PREFIX."_users where parent_id='$parentId' AND position ='$position'");
		$qr = $this->numRows($q);
		if($qr == 0){
			$result = 1;
		}else{
			$result = 0;
		}
		return $result;
	}	
	function statusRemove($id){
		$q=$this->query("update ".TBL_PREFIX."_users set status = 2, updated = NOW()  where uid=$id");
		$this->commonObjContent->pushMessage("User has been removed successfully.");
		$this->commonObjContent->wtRedirect("user.php");	
	}
	
	function getUser($id){
		$q=$this->query("select * from ".TBL_PREFIX."_users where uid='$id' OR user_pin ='$id'");
		$qr=$this->fetchNextObject($q);
		return $qr;
	}
	function getUserChild($id){
	    $result = array();
		$q=$this->query("select * from ".TBL_PREFIX."_users where parent_id='$id'");
		while($qr = $this->fetchNextObject($q)){
			if($qr->position == 1){
				$result['RightUser'] = 'SM100'.$qr->uid;
			}
			else{
				$result['LeftUser'] = 'SM100'.$qr->uid;
			}
		}
		return $result;
	}
	function getUserWallet($params){
	$searchQ = '';
	$sortby = 'DESC';
	$col = 'cid';
	
	if (isset($params['sort'])) {  
  		$sortby = $params['sort'];
	}
	if (isset($params['column'])) {  
  		$col = $params['column'];
	}
  	$start=0;
	$limit=10;

	if(isset($params['page']))
	{
	$id = $params['page'];
	$start=($id-1)*$limit;
	}
	//echo "select * from ".TBL_PREFIX."_user_commission where uid='".$_SESSION['UID']."' ORDER BY $col $sortby LIMIT $start, $limit";
		$q=$this->query("select * from ".TBL_PREFIX."_user_commission where uid='".$_SESSION['UID']."' ORDER BY $col $sortby LIMIT $start, $limit");		
		return $q;
	}
	function getUserByPin($id){
		$q=$this->query("select * from ".TBL_PREFIX."_users where  user_pin ='$id'");
		$qr=$this->fetchNextObject($q);
		return $qr;
	}
	function changePassword($old_password,$new_password){
		$Arr  = $this->query("select * from ".TBL_PREFIX."_users where password = '$old_password' and uid=".$_SESSION['UID'],$debug=-1);
		$rows = $this->numRows($Arr);
		if($rows > 0){
		$this->query("update ".TBL_PREFIX."_users set password = '$new_password' where uid=".$_SESSION['UID']);
		$this->commonObjContent->pushMessage("Password changed sucessfully.");		
		} else {
			$this->commonObjContent->pushError("Old password is wrong.");
		}
	}
	function fetchAllUsers(){
		$q=$this->query("select * from ".TBL_PREFIX."_users where 1 = 1");
		return $q;
	}
	function fetchAllAssignedUsersPin($uid){
		$q=$this->query("select * from ".TBL_PREFIX."_tokens where assign_to_user = $uid");
		return $q;
	}
	function fetchAll($params){
	$searchQ = '';
	$sortby = 'ASC';
	$col = 'uid';
	if (isset($params['searchQry'])) {  
  		$searchQ = " AND username LIKE '%".$params['searchQry']."%'";
		
	}
	if (isset($params['sort'])) {  
  		$sortby = $params['sort'];
	}
	if (isset($params['column'])) {  
  		$col = $params['column'];
	}
  	$start=0;
	$limit=10;

	if(isset($params['page']))
	{
	$id = $params['page'];
	$start=($id-1)*$limit;
	}
	//echo "select * from ".TBL_PREFIX."_users where status != 2  ORDER BY $col $sortby LIMIT $start, $limit";
		$q=$this->query("select * from ".TBL_PREFIX."_users where status != 2 $searchQ ORDER BY $col $sortby LIMIT $start, $limit");
		return $q;
	}
	
	function AssignedUsersPin($params,$front = null){
	if($front == 'front'){
	$uid = intval($_SESSION['UID']);
	}else{
	$uid = intval($params['uid']);
	}
	$searchQ = '';
	$sortby = 'ASC';
	$col = 'tid';
	if (isset($params['searchQry'])) {  
  		$searchQ = " AND username LIKE '%".$params['searchQry']."%'";
		
	}
	if (isset($params['sort'])) {  
  		$sortby = $params['sort'];
	}
	if (isset($params['column'])) {  
  		$col = $params['column'];
	}
  	$start=0;
	$limit=10;

	if(isset($params['page']))
	{
	$id = $params['page'];
	$start=($id-1)*$limit;
	}
	//echo "select * from ".TBL_PREFIX."_users where status != 2  ORDER BY $col $sortby LIMIT $start, $limit";
		$q=$this->query("select * from ".TBL_PREFIX."_tokens where assign_to_user = ".$uid." $searchQ ORDER BY $col $sortby LIMIT $start, $limit");
		return $q;
	}
		
	function modifyStatus($params){
	
	$userData = $this->getUser($_POST['uid']);
	if($userData->user_pin == ''){
		$this->commonObjContent->pushError("You need to assign user pin before processing.");
		return('success');
		//
	}else{
		if($this->commonObjContent->praseData($_POST['action']) == 'active'){
			$val = 1;
		}else{
			$val = 0;
		}
			$query = "update ".TBL_PREFIX."_users set status =".$val.",updated = NOW() where uid=".intval($_POST['uid']);
			$q = $this->query($query);
			if($q){
				return('success');
			}else{
				return('fail');
			}
		}	
	}
	
	function login($id,$password){			
		$del="SM100";
		$pos=strpos($id, $del);
		$id=substr($id, $pos+strlen($del)-0, strlen($id)-0);

		$query = "SELECT * FROM ".TBL_PREFIX."_users where uid='".$id."' and password='".$password."'";
		$loginRs =$this->query($query,-1);
		if($this->numRows($loginRs)==0) {
			$this->commonObjContent->pushError('Invalid login');
			$this->commonObjContent->wtRedirect("login.php");
		} else {		
			$loginRsObj = $this->fetchNextObject($loginRs);
			/*if($loginRsObj->status == 0) {
				$this->commonObjContent->pushError('Account is not active.');
				$this->commonObjContent->wtRedirect("login.php");
			}else{
				$_SESSION["UNAME"] = $loginRsObj->username;
				$_SESSION["UID"] = $loginRsObj->uid;			
				$this->commonObjContent->wtRedirect("dashboard.php");
			}*/
				$_SESSION["UNAME"] = $loginRsObj->username;
				$_SESSION["UID"] = $loginRsObj->uid;			
				$this->commonObjContent->wtRedirect("dashboard.php");
		}
	}
	function logout(){
		$_SESSION["UNAME"] = null;
		$_SESSION["UID"] = null;		
		$this->commonObjContent->pushMessage("Logout successful");
		//session_destroy();
		$this->commonObjContent->wtRedirect("index.php");
	
	}
	
	function DeleteModel($ModelId){		
	$q = $this->query("SELECT tbl_model.*,tbl_model_pics.* FROM tbl_model LEFT JOIN tbl_model_pics ON tbl_model.id = tbl_model_pics.model_id where tbl_model.id = '$ModelId'");
		/*while($line = $this->fetchNextObject($q)){ 
		unlink("../uploaded_images/".stripslashes($line->model_image_name));
		unlink("../uploaded_images/".stripslashes($line->model_master_image));
		unlink("../uploaded_images/thumb/".stripslashes($line->model_master_image));
		}*/
		$this->query("DELETE FROM tbl_model WHERE id='$ModelId'");
		$this->query("DELETE FROM tbl_model_cover_photo WHERE model_id='$ModelId'");
		$this->query("DELETE FROM tbl_model_pics WHERE model_id='$ModelId'");
		
		$this->commonObjContent->pushMessage("Model has been removed successfully.");
		$this->commonObjContent->wtRedirect("models.php");
		}
			
}
?>