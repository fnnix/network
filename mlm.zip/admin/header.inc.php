<div class="header-section">
    <div class="logo-section"><a href="admin-dashboard.php"><h1><?php echo SITE_ADMIN_TITLE; ?></h1></a></div>
 </div>