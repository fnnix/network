<?php /*?><!--<table width="100%"  border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td class="footer">Copyright &copy; <?php echo SITE_TITLE;?></td>
  </tr>
</table>--><?php */?>
<div class="footer-section">
<div class="footer-area">
<div class="footer-left">&copy; <?php echo SITE_TITLE;?> <?php echo date('Y');?>. All rights reserved.</div>
<div class="footer-right">
<a href="#"><img src="../images/facebook-icon.png" alt="" /></a> 
<a href="#"><img src="../images/in-icon.png" alt="" /></a>
<a href="#"><img src="../images/twitter-icon.png" alt="" /></a> 
<a href="#"><img src="../images/rss.png" alt="" /></a>
</div>
</div>
</div>