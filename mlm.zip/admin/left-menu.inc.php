<table width="100%"  border="0" cellspacing="0" cellpadding="0" align="right">
<tr >
	<td height="30" align="left" valign="middle" class="menuLeft"><a href="admin-home.php" class="menuBoldText">Home</a></td>
</tr>

<tr >
	<td height="50" align="left" class="menuLeft"><div class="menuBoldText">Pin Manager</div>
	<div class="subMenu"><a href="package.php" class="menuLinks">Manage Pin</a></div>
	
	</td>
</tr>

<tr >
	<td height="50" align="left" class="menuLeft"><div class="menuBoldText">User Manager</div>
	<div class="subMenu"><a href="user.php" class="menuLinks">Manage User</a></div>
	
	</td>
</tr> 

<tr >
	<td height="50" align="left" class="menuLeft"><div class="menuBoldText">Commission Manager</div>
	<div class="subMenu"><a href="commission-setting.php" class="menuLinks">Manage Commission</a></div>
	
	</td>
</tr> 


<tr >
	<td height="50" align="left" class="menuLeft"><div class="menuBoldText">Admin Manager</div>
	<div class="subMenu"><a href="change-password.php" class="menuLinks">Change Password</a></div>
	<div class="subMenu"><a href="change-email.php" class="menuLinks">Change Email</a></div>
	</td>
</tr> 

<tr>
	<td height="30" align="left" class="menuLeft"><a href="logout.php" class="menuBoldText">Logout</a></td>
</tr>

<tr>
	<td><img src="images/spacer.gif" width="1" height="1" /></td>
</tr>
</table>

