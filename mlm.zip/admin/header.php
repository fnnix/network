  <div class="header-section">
    <div class="logo-section"><a href="../index.php">Alexandra Leese</a></div>
    <!--<div class="top-menu">
    <ul>
    <li><a href="../fashion.php" id="various1">Fashion</a></li>
    <li><a href="../portraits.php" id="various2">Portraits</a></li>
    <li><a href="../life.php" id="various3">Life</a></li>
    <li><a href="../about.php" id="various4">About</a></li>
    <li><a href="../contact.php" id="various5">Contact</a></li>
    <li style="border-right:none"><a href="../blog.php" id="various6">Blog</a></li>  
    </ul>
    </div>-->
  </div>