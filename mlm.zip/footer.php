<div class="footer-section">
<div class="footer-area">
<div class="footer-left">&copy; <?php echo SITE_TITLE;?>.com. <?php echo date('Y');?>. All rights reserved.</div>
<div class="footer-right">
<a href="#"><img src="images/facebook-icon.png" alt="" /></a> 
<a href="#"><img src="images/in-icon.png" alt="" /></a>
<a href="#"><img src="images/twitter-icon.png" alt="" /></a> 
<a href="#"><img src="images/rss.png" alt="" /></a>
</div>
</div>
</div>
