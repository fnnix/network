<?php
require_once("lib/config.inc.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Success Mission Infocom (P) Ltd.</title>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
-->
</style>
<script type="text/javascript" src="js/boxover.js"></script>
<style type="text/css">
.mainTable {
	border:#666666 1px solid;
}
.mainTable td {
	font-family:Tahoma, Geneva, sans-serif;
	font-size:.9em;
	text-align:center;
	cursor:default;
}
.internalTable td {
	font-family:Tahoma, Geneva, sans-serif;
	font-size:.9em;
	border:#666666 1px dotted;
	text-align:center;
	cursor:default;
}
.toolHeader {
	background-color: #D3E4A6;
	font-family:Arial, Tahoma;
	font-weight: bold;
	font-size:12px;
	color: Black;
	padding: 3px;
	border: solid 2px #9CC525;
}
.toolBody {
	background:#FFFFFF;
	font-family:Arial, Tahoma;
	font-size:12px;
	padding:5px;
	border: solid 2px #9CC525;
	border-top:none;
	color: Blue;/* color: #F4921B; */
}
</style>
<link href="css/For-text.css" rel="stylesheet" type="text/css" />
</head>
<body>
<table width="980" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><?php include("header.php"); ?></td>
  </tr>
  <tr bgcolor="#FFFFFF">
    <td height="1"></td>
  </tr>
  <tr>
    <td><table width="980" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td width="12" bgcolor="#FFFFFF">&nbsp;</td>
          <td width="670"><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0" width="670" height="217" align="top">
              <param name="movie" value="flash/banner.swf" />
              <param name="quality" value="high" />
              <embed src="flash/banner.swf" width="670" height="217" align="top" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash"></embed>
            </object></td>
          <td width="10" bgcolor="#FFFFFF">&nbsp;</td>
          <td width="276" valign="top"><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0" width="276" height="217" align="top">
              <param name="movie" value="flash/testimonials.swf" />
              <param name="quality" value="high" />
              <embed src="flash/testimonials.swf" width="276" height="217" align="top" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash"></embed>
            </object></td>
          <td width="12">&nbsp;</td>
        </tr>
      </table></td>
  </tr>
  <tr>
    <td><table width="980" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td width="181" height="381" valign="top"><table width="181" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0" width="181" height="113" align="top">
                    <param name="movie" value="flash/side.swf" />
                    <param name="quality" value="high" />
                    <embed src="flash/side.swf" width="181" height="113" align="top" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash"></embed>
                  </object></td>
              </tr>
              <tr>
                <td><table width="181" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                      <td width="3" height="268" bgcolor="#FFFFFF">&nbsp;</td>
                      <td width="178" valign="top"><form action="login.php" method="post" name="formLogMen" id="formLogMen" onSubmit="return validate_form()">
                          <table width="178" border="0" cellspacing="0" cellpadding="0">
                            <tr>
                              <td><img src="images/login.jpg" width="178" height="34" /></td>
                            </tr>
                            <tr>
                              <td height="22" background="images/login2.jpg">&nbsp;</td>
                            </tr>
                            <tr>
                              <td height="17" background="images/login2.jpg" class="For-login">Track Id</td>
                            </tr>
                            <tr>
                              <td height="30" background="images/login3.jpg">&nbsp;
                                <input type="text" name="user_email" /></td>
                            </tr>
                            <tr>
                              <td height="19" background="images/login4.jpg"><span class="For-login">Password</span></td>
                            </tr>
                            <tr>
                              <td height="30" background="images/login5.jpg">&nbsp;
                                <input type="password" name="password" /></td>
                            </tr>
                            <tr>
                              <td height="35" background="images/login6.jpg"><table width="178" border="0" cellspacing="0" cellpadding="0">
                                  <tr>
                                    <td width="80" height="35">&nbsp;
                                      <input type="submit" name="Submit" value="Submit" /></td>
                                    <td width="98"><input type="reset" name="Submit2" value="Reset" /></td>
                                  </tr>
                                </table></td>
                            </tr>
                            <tr>
                              <td height="40" background="images/login7.jpg"><table width="178" border="0" cellspacing="0" cellpadding="0">
                                  <tr>
                                    <td width="100" height="40" align="center" class="For-text2">Forget Password</td>
                                    <td width="6" valign="middle">|</td>
                                    <td width="72" align="center" class="For-text3">Pan Update</td>
                                  </tr>
                                </table></td>
                            </tr>
                            <tr>
                              <td height="41" bgcolor="#FFFFFF">&nbsp;</td>
                            </tr>
                          </table>
                        </form></td>
                    </tr>
                  </table></td>
              </tr>
            </table></td>
          <td width="542" valign="top"><table width="542" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td height="27" background="images/text.jpg" class="For-heading">&nbsp;&nbsp;Binary Tree<div style="float:right"><input type="button" name="btnBack" id="btnBack" value="Back" onclick="javascript:history.back();" /></div></td>
              </tr>
              <tr>
                <td height="61" valign="top" class="For-text4"><table width="542" border="1" cellpadding="0" cellspacing="0">
                    <tr>
                      <td height="20" colspan="3" align="center" class="link"><?php
	GenerateTree('SM1002');

function GenerateTree($xMember_ID){
	$l1="<table width='100%' cellpadding='0' cellspacing='0' border='0'><tr><td align='center'><img src='images/inactive.png'></td><td align='center'><img src='images/inactive.png'></td></tr></table>";
	$l2="<table width='100%' cellpadding='0' cellspacing='0' border='0'><tr><td align='center'><img src='images/inactive.png'></td><td align='center'><img src='images/inactive.png'></td></tr></table>";

	
	$xMember_Root = mysql_query("SELECT * FROM tbl_users where uid = 2");
	$xMembers = mysql_query("SELECT * FROM members where parent_id='".$xMember_ID."'");
	
	for($i=0; $i<count($xMembers); $i++)
	{
		if($xMembers[$i]["Position"]== "2"){$l1=getDownline($xMembers[$i]["Member_ID"]);}
		if($xMembers[$i]["Position"]== "1"){$l2=getDownline($xMembers[$i]["Member_ID"]);}
	}

	if($xMember_Root[0]["Status"]=="0")
		echo "<img src='images/disabled.png' title='".getToolTip($xMember_ID)."'>";
	else
		echo "<img src='images/active.png' title='".getToolTip($xMember_ID)."'>";

	echo "<table border='0' cellspacing='0' cellpadding='3' style='width:100%; text-align:center'>";
	echo "<tr><td colspan='3' style='text-align:center;'>".getInfo($xMember_ID)."<br>".(($xMember_Root[0]["Member_ID_Parent"]!="0" && $xMember_Root[0]["Member_ID"] != 'SM1002')?"<a href='binarytree.php?txtMember_ID=".$xMember_Root[0]["Member_ID_Parent"]."' style='color:#333'>Up Level</a>":"")."</td></tr>";
	echo "<tr><td colspan='3'>".getDownline($xMember_ID)."</td></tr>";
	echo "<tr><td style='width:33%;' align='center'>".$l1."</td><td style='width:33%;' align='center'>".$l2."</td></tr>";
	echo "</table>";
}

function getDownline($xMember_ID){
	
	$xMembers = mysql_fetch_assoc(mysql_query("SELECT * FROM tbl_users where parent_id='".$xMember_ID."'"));

	$final = "<table border='0' style='width:100%;' cellspacing='0' cellpadding='0'>";
	$final .= "<tr>";
	
	$nothing=true;
	$x=0;
	$xPosition='';
	$xLeft_Node="<td align='center'><img src='images/inactive.png'></td>";
	$xRight_Node="<td align='center'><img src='images/inactive.png'></td>";
	
	for($i=0; $i<count($xMembers); $i++)
	{
		$x++;
		$xPosition=$xMembers[$i]["Position"];
		if($xPosition=="2"){
			$xLeft_Node="<td align='center'>";
			if($xMembers[$i]["Status"]=="0")
				$xLeft_Node .= "<a href='binarytree.php?txtMember_ID=".$xMembers[$i]["uid"]."'><img src='images/disabled.png' title='".getToolTip($xMembers[$i]["uid"])."' border='0'></a>";
			else
				$xLeft_Node.= "<a href='binarytree.php?txtMember_ID=".$xMembers[$i]["uid"]."'><img src='images/active.png' title='".getToolTip($xMembers[$i]["uid"])."' border='0'></a>";
			$xLeft_Node.="<br />".getInfo($xMembers[$i]["uid"])."</td>";
			
		}

		if($xPosition=="1"){ 
			$xRight_Node="<td align='center'>";
			if($xMembers[$i]["Status"]=="0")
				$xRight_Node .= "<a href='binarytree.php?txtMember_ID=".$xMembers[$i]["uid"]."'><img src='images/disabled.png' title='".getToolTip($xMembers[$i]["uid"])."' border='0'></a>";
			else
				$xRight_Node .= "<a href='binarytree.php?txtMember_ID=".$xMembers[$i]["uid"]."'><img src='images/active.png' title='".getToolTip($xMembers[$i]["uid"])."' border='0'></a>";
			$xRight_Node.="<br />".getInfo($xMembers[$i]["uid"])."</td>";
		}
		$nothing=false;
	}
	
	$final .= $xLeft_Node.$xRight_Node;
	$final .= "</tr>";
	$final .= "</table>";
	
	return $final;
}
		
function getToolTip(){
	$id = 2;
	$xMembers = mysql_fetch_object(mysql_query("SELECT * FROM tbl_users where uid='".$id."'"));

    return "fade=[off] cssheader=[toolHeader] cssbody=[toolBody] header=[Detail For ID ".$id."] body=[".$xMembers->username."<br />Address:".$xMembers->address."<br />Email:".$xMembers->email."]";
}

function getInfo($id){
	
	$xMembers = mysql_fetch_object(mysql_query("SELECT * FROM tbl_users where uid='".$id."'"));
	return $xMembers->username;
}
?></td>
                    </tr>
                  </table></td>
              </tr>
              <tr></tr>
            </table></td>
          <td width="257" valign="top"><table width="257" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td><img src="images/may-i.jpg" width="257" height="134" /></td>
              </tr>
              <tr>
                <td align="center"><table width="257" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                      <td width="80" height="100" valign="top" class="For-heading">E-Mail</td>
                      <td align="left"><img src="images/email.jpg" width="91" height="84" /></td>
                      <td>&nbsp;</td>
                    </tr>
                  </table></td>
              </tr>
              <tr>
                <td><table width="257" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                      <td width="7">&nbsp;</td>
                      <td width="237" align="center"><img src="images/photo-gallery.jpg" width="152" height="155" /></td>
                      <td width="13">&nbsp;</td>
                    </tr>
                  </table></td>
              </tr>
              <tr>
                <td height="1"></td>
              </tr>
              <tr>
                <td><table width="257" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                      <td width="7">&nbsp;</td>
                      <td width="237">&nbsp;</td>
                      <td width="13">&nbsp;</td>
                    </tr>
                  </table></td>
              </tr>
            </table></td>
        </tr>
      </table></td>
  </tr>
  <tr>
    <td><?php include_once("footer.php"); ?></td>
  </tr>
</table>
</body>
</html>
